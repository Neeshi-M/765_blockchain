1- Open a local terminal and run :  ganache-cli
2 - Open terminal in the main directory and run:  truffle migrate
3 - Copy the "Contract address" from the above commands output and paste it inside client.py codes lines 19 to the variable "deployed_contract_address".
4 - After saving the client.py to run our code, run:  python3 client.py 